/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TabType = 'quantum' | 'neural' | 'sub-orbital' | 'overview';

export interface ProjectType {
  id: string;
  codeName: string;
  title: string;
  description: string;
  version: string;
  status: 'active' | 'calibrating' | 'standby';
  metricName: string;
  metricValue: string;
}

export interface TechItemType {
  name: string;
  category: string;
  description: string;
  spec: string;
  status: string;
}

export interface TelemetryMetrics {
  networkDensity: number; // Pbps
  latency: number; // ms
  nodeCount: number;
  uptime: number; // %
}

export interface TerminalLog {
  timestamp: string;
  sender: 'SYS' | 'USER' | 'WARN' | 'OK';
  message: string;
}
