/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal as TerminalIcon, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Play, 
  BookOpen, 
  CheckCircle, 
  Activity, 
  Code,
  Globe,
  Database
} from 'lucide-react';
import { TabType, ProjectType, TechItemType, TelemetryMetrics, TerminalLog } from './types';
import ConsoleTerminal from './components/ConsoleTerminal';
import TabPanels from './components/TabPanels';

// Tech stack items shown in Right Column
const TECH_STACK: TechItemType[] = [
  {
    name: 'React 19.0',
    category: 'Core Engine',
    description: 'Declarative component composition utilizing concurrent rendering models and strict state encapsulation.',
    spec: 'Framework Architecture: Fiber DOM // Render Pipelines: Reactive Hydration // Scheduler: Prioritized Task Queues',
    status: 'OPTIMAL',
  },
  {
    name: 'TypeScript',
    category: 'Type Safety',
    description: 'Strict compile-time verification validating system data boundaries, interface payloads, and telemetry logs.',
    spec: 'Type Engine: v5.8.2 // Transpilation: Standalone ESM // Linters: Strict Null Checks Enabled',
    status: 'STABLE',
  },
  {
    name: 'Tailwind v4',
    category: 'Design Sys',
    description: 'Utility-first utility compiler using state-of-the-art modern CSS engine architectures for atomic styling.',
    spec: 'CSS Spec: CSS-variables based // Compiler: Lightning CSS // Postprocessing: Native Autoprefixer',
    status: 'ACTIVE',
  },
  {
    name: 'Motion 12',
    category: 'Animations',
    description: 'Hardware-accelerated fluid transitions and physics-based animations guiding user-spatial attention.',
    spec: 'Library: motion/react // Engine: Web Animations API // Composites: Sub-millisecond FPS locks',
    status: 'STANDBY',
  },
];

// Available projects to cycle in Right Column
const PROJECTS: ProjectType[] = [
  {
    id: 'MSJ-FT-01',
    codeName: 'Neural Mesh',
    title: 'MSJ-FT-01',
    description: 'Initialization of the global neural mesh and decentralized data storage systems across localized edge clusters.',
    version: 'V 4.0.21',
    status: 'active',
    metricName: 'Node Density',
    metricValue: '44.2 Pbps',
  },
  {
    id: 'MSJ-QT-02',
    codeName: 'Crypton-Q',
    title: 'MSJ-QT-02',
    description: 'Simulation of multi-qubit coherent lattices protecting inter-orbital relays from quantum cryptanalysis.',
    version: 'V 2.1.0-A',
    status: 'calibrating',
    metricName: 'Qubit Count',
    metricValue: '16 Coherent',
  },
  {
    id: 'MSJ-SO-03',
    codeName: 'GeoUplink-S',
    title: 'MSJ-SO-03',
    description: 'High-frequency telemetry routing protocol linking low-orbit nodes with deep-sea atmospheric sensor cables.',
    version: 'V 9.3.4-C',
    status: 'standby',
    metricName: 'Azimuth Accuracy',
    metricValue: '224.12° Opt',
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [currentProjectIndex, setCurrentProjectIndex] = useState(0);
  const [selectedTech, setSelectedTech] = useState<TechItemType | null>(null);
  const [showSourceCode, setShowSourceCode] = useState<ProjectType | null>(null);
  
  // Console terminal states
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);
  const [logs, setLogs] = useState<TerminalLog[]>([
    {
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: 'MSJ System Terminal Initialized. Ready for telemetry commands.',
    },
    {
      timestamp: new Date().toLocaleTimeString(),
      sender: 'OK',
      message: 'Secure channel handshake complete. Encryption algorithm active.',
    },
  ]);

  // Real-time telemetry metrics
  const [metrics, setMetrics] = useState<TelemetryMetrics>({
    networkDensity: 44.2,
    latency: 0.002,
    nodeCount: 14291,
    uptime: 99.9,
  });

  // Cycle through live metrics fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics((prev) => {
        const densityDelta = (Math.random() - 0.5) * 0.15;
        const latencyDelta = (Math.random() - 0.5) * 0.0003;
        const nodeDelta = Math.random() > 0.85 ? (Math.random() > 0.5 ? 1 : -1) : 0;
        
        return {
          networkDensity: parseFloat(Math.max(10, prev.networkDensity + densityDelta).toFixed(1)),
          latency: parseFloat(Math.max(0.0001, prev.latency + latencyDelta).toFixed(4)),
          nodeCount: prev.nodeCount + nodeDelta,
          uptime: prev.uptime, // Keep stable unless calibrated
        };
      });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Sync log list helper
  const addLog = (log: TerminalLog) => {
    setLogs((prev) => [...prev, log]);
  };

  const clearLogs = () => {
    setLogs([]);
  };

  // Run mock telemetry actions triggered from terminal
  const runSimulation = (type: 'quantum' | 'neural' | 'sub-orbital') => {
    if (type === 'quantum') {
      setActiveTab('quantum');
      addLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: 'COLLAPSED LOCAL RE-INTEGRATOR FIELD. QUANTUM TELEMETRY ACTIVE.',
      });
    } else if (type === 'neural') {
      setActiveTab('neural');
      addLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: 'GRADIENT SHIFT SUCCESSFUL. GRADIENTS DEPLOYED TO EDGE CORE.',
      });
    } else if (type === 'sub-orbital') {
      setActiveTab('sub-orbital');
      addLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: 'PING BEACON CONFIRMED BY CO-ORBITAL PLATFORM SAT-4A.',
      });
    }
    setIsConsoleOpen(false);
  };

  const handlePingComplete = (pingVal: number) => {
    setMetrics((prev) => ({
      ...prev,
      latency: parseFloat((pingVal / 1500).toFixed(4)), // Sync with global latency scale
    }));
  };

  const handleUptimeRecalibrate = () => {
    addLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: 'CALIBRATING CORE RESILIENCY COEFFICIENT...',
    });
    
    // Simulate minor percentage increase
    setTimeout(() => {
      setMetrics((prev) => ({
        ...prev,
        uptime: 99.98,
      }));
      addLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: 'UPTIME COEFFICIENT RESTORED TO OPTIMAL 99.98%.',
      });
    }, 1500);
  };

  const activeProject = PROJECTS[currentProjectIndex];

  // Helper to generate source code representation based on project
  const getProjectCode = (project: ProjectType) => {
    if (project.id === 'MSJ-FT-01') {
      return `/**
 * MSJ-FT-01 // NEURAL MESH COUPLING AGENT
 * Distributed backpropagation and weight alignment
 */
import { NeuralMesh, EdgeCluster } from '@msj/neural-core';

export async function initializeMesh() {
  const cluster = new EdgeCluster({
    region: "global-edge-mesh",
    gateways: ${metrics.nodeCount}
  });

  const mesh = new NeuralMesh({
    layers: [512, 1024, 1024, 512],
    activation: 'leaky_relu',
    leakRate: 0.01
  });

  console.log("Instantiating localized backpropagation matrix...");
  await mesh.couple(cluster);

  const stats = await mesh.evaluateGradients();
  return {
    status: "OPTIMAL",
    loss: stats.averageLoss,
    bandwidth: "${metrics.networkDensity} Pbps"
  };
}`;
    } else if (project.id === 'MSJ-QT-02') {
      return `/**
 * MSJ-QT-02 // COHERENT REGISTER INTERFACE
 * Inter-orbital quantum cryptographic key negotiation
 */
import { QubitLattice, Entangler } from '@msj/quantum';

export function measureState(registerSize = 16) {
  const lattice = new QubitLattice(registerSize);
  
  // Entangle register states to produce bell-pairs
  Entangler.couple(lattice.qubits[0], lattice.qubits[15]);
  
  const measured = lattice.measureAll();
  const entropy = lattice.calculateShannonsEntropy();

  return {
    qubitCount: lattice.size,
    entropyCoefficient: entropy,
    phaseCoherence: "99.98%",
    registerValues: measured.binaryString
  };
}`;
    } else {
      return `/**
 * MSJ-SO-03 // GEO-ORBITAL TELEMETRY UPLINK
 * constellation satellite link-state controller
 */
import { GeoSatellite, TelemetryChannel } from '@msj/orbital';

export async function synchronizeOrbitalUplink() {
  const satellite = new GeoSatellite({
    codename: "SAT-4A",
    orbitType: "LEO",
    altitudeKm: 412.4
  });

  const channel = new TelemetryChannel({
    protocol: "high-freq-ultraband",
    frequencyGhz: 48.2
  });

  console.log("Transmitting synchronization beacon...");
  const pingReport = await channel.sendPing(satellite);

  return {
    signalStrength: "98.2%",
    roundTripMs: pingReport.latencyMs,
    azimuthAlignment: "224.12deg"
  };
}`;
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F5F5F5] font-sans flex flex-col justify-between overflow-x-hidden antialiased select-none selection:bg-white selection:text-black">
      
      {/* 1. HEADER / NAVIGATION */}
      <nav className="flex flex-col md:flex-row justify-between items-center px-6 md:px-12 py-6 border-b border-white/10 gap-6 md:gap-0 bg-black/40 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center gap-4">
          {/* Logo diamond icon */}
          <div className="w-10 h-10 bg-white flex items-center justify-center rounded-sm shrink-0 shadow-lg">
            <div className="w-6 h-6 border-2 border-black rotate-45 transition-transform duration-700 hover:rotate-90"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tighter uppercase font-sans">MSJ / Tech</span>
            <span className="text-[9px] font-mono tracking-widest text-white/40 uppercase">editorial portal</span>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap gap-x-6 gap-y-3 justify-center text-[10px] font-bold tracking-[0.2em] uppercase text-white/50">
          <button
            onClick={() => setActiveTab('overview')}
            className={`hover:text-white transition-colors uppercase ${activeTab === 'overview' ? 'text-white border-b-2 border-white pb-1' : ''}`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('quantum')}
            className={`hover:text-white transition-colors uppercase ${activeTab === 'quantum' ? 'text-white border-b-2 border-white pb-1' : ''}`}
          >
            Quantum Lab
          </button>
          <button
            onClick={() => setActiveTab('neural')}
            className={`hover:text-white transition-colors uppercase ${activeTab === 'neural' ? 'text-white border-b-2 border-white pb-1' : ''}`}
          >
            Neural Net
          </button>
          <button
            onClick={() => setActiveTab('sub-orbital')}
            className={`hover:text-white transition-colors uppercase ${activeTab === 'sub-orbital' ? 'text-white border-b-2 border-white pb-1' : ''}`}
          >
            Sub-Orbital
          </button>
        </div>

        {/* Action Button */}
        <button
          onClick={() => setIsConsoleOpen(true)}
          className="px-6 py-2.5 border border-white/30 hover:border-white text-[10px] uppercase tracking-widest hover:bg-white hover:text-black transition-all font-mono font-semibold shadow-md shrink-0 flex items-center gap-2"
        >
          <TerminalIcon className="w-3.5 h-3.5" />
          Launch Console
        </button>
      </nav>

      {/* 2. MAIN SPLIT PANEL */}
      <main className="flex-1 flex flex-col lg:flex-row">
        
        {/* Left Column (60% Width, border right separation) */}
        <div className="w-full lg:w-[60%] p-6 md:p-12 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10 min-h-[450px] lg:min-h-0 bg-gradient-to-br from-[#0A0A0A] via-[#0D0D0D] to-[#0A0A0A]">
          <TabPanels
            activeTab={activeTab}
            metrics={metrics}
            onPingComplete={handlePingComplete}
            onUptimeRecalibrate={handleUptimeRecalibrate}
            onAddLog={addLog}
          />
        </div>

        {/* Right Column (40% Width, background white/5 accent) */}
        <div className="w-full lg:w-[40%] bg-white/[0.015] p-6 md:p-12 flex flex-col justify-between gap-12 bg-gradient-to-b from-transparent to-[#0A0A0A]/40">
          
          {/* Tech Stack Spec Grid */}
          <div>
            <div className="text-[10px] uppercase tracking-[0.3em] mb-8 text-white/30 font-mono flex items-center gap-2">
              <Database className="w-4 h-4 text-white/40" />
              Mainframe Stack Spec
            </div>
            <ul className="space-y-6">
              {TECH_STACK.map((item) => (
                <li key={item.name} className="border-b border-white/5 pb-4">
                  <div 
                    onClick={() => setSelectedTech(selectedTech?.name === item.name ? null : item)}
                    className="flex justify-between items-baseline group cursor-pointer focus:outline-none"
                  >
                    <span className="text-xl md:text-2xl font-serif italic text-white/90 group-hover:text-white transition-colors">
                      {item.name}
                    </span>
                    <span className="h-px flex-1 mx-4 bg-white/5 group-hover:bg-white/15 transition-all"></span>
                    <span className="text-[10px] font-mono opacity-50 group-hover:opacity-80 transition-opacity flex items-center gap-1.5 uppercase">
                      {item.category}
                      <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                  
                  {/* Expandable spec panel */}
                  <AnimatePresence>
                    {selectedTech?.name === item.name && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-3 p-4 bg-white/[0.02] border border-white/5 text-xs text-white/70 font-sans leading-relaxed flex flex-col gap-2">
                          <p>{item.description}</p>
                          <div className="mt-1 pt-2 border-t border-white/5 font-mono text-[9px] text-white/40 flex justify-between items-center">
                            <span>{item.spec}</span>
                            <span className="text-emerald-400 uppercase font-bold text-[8px] bg-emerald-500/10 px-1.5 py-0.5 rounded-xs">
                              {item.status}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </li>
              ))}
            </ul>
          </div>

          {/* Active Project Widget with Interactive cycling */}
          <div className="mt-auto">
            <div className="p-6 bg-white text-black rounded-xs shadow-xl relative overflow-hidden group">
              
              {/* Cycling Controls */}
              <div className="absolute top-6 right-6 flex gap-1 bg-black/5 p-1 rounded-sm">
                <button
                  onClick={() => setCurrentProjectIndex((prev) => (prev === 0 ? PROJECTS.length - 1 : prev - 1))}
                  className="p-1 hover:bg-black/10 rounded-xs transition-colors"
                  title="Previous project"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setCurrentProjectIndex((prev) => (prev === PROJECTS.length - 1 ? 0 : prev + 1))}
                  className="p-1 hover:bg-black/10 rounded-xs transition-colors"
                  title="Next project"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Status Header */}
              <div className="flex justify-between items-center mb-6 pr-12">
                <span className="text-[10px] font-bold uppercase tracking-widest text-black/55">
                  Active Operational Node
                </span>
                <span className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${
                    activeProject.status === 'active' 
                      ? 'bg-red-500 animate-pulse' 
                      : activeProject.status === 'calibrating'
                      ? 'bg-amber-500 animate-pulse-slow'
                      : 'bg-blue-500'
                  }`} />
                  <span className="text-[9px] font-mono uppercase text-black/50 font-bold">
                    {activeProject.status}
                  </span>
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-3xl font-black uppercase leading-none mb-3 font-sans tracking-tight text-black">
                {activeProject.title}
              </h3>
              <p className="text-xs text-black/75 mb-6 leading-relaxed">
                {activeProject.description}
              </p>

              {/* Metadata row */}
              <div className="flex justify-between items-center text-[10px] font-bold uppercase border-t border-black/10 pt-4 mt-2">
                <div className="flex items-center gap-3">
                  <span className="text-black/50">{activeProject.version}</span>
                  <span className="text-black/30 font-mono">|</span>
                  <span className="text-black/60 font-mono">
                    {activeProject.metricName}: <span className="font-sans font-bold text-black">{activeProject.metricValue}</span>
                  </span>
                </div>
                <button
                  onClick={() => setShowSourceCode(activeProject)}
                  className="underline underline-offset-4 cursor-pointer hover:opacity-80 transition-opacity flex items-center gap-1"
                >
                  <Code className="w-3.5 h-3.5" />
                  View Source
                </button>
              </div>
            </div>
          </div>

        </div>
      </main>

      {/* 3. BOTTOM FOOTER TICKER */}
      <footer className="py-6 border-t border-white/10 flex flex-col md:flex-row items-center px-6 md:px-12 bg-black/60 gap-4 md:gap-0 font-mono">
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[10px] text-white/30">SYST_STATUS:</span>
          <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>
            OPTIMAL
          </span>
        </div>

        {/* Real-time fluctuating telemetry ticker */}
        <div className="flex-1 flex justify-center w-full overflow-hidden">
          <div className="flex flex-wrap gap-x-8 gap-y-1 text-[9px] uppercase tracking-[0.2em] text-white/40 justify-center">
            <span className="flex items-center gap-1.5">
              Network Density: <span className="text-white font-mono font-medium">{metrics.networkDensity} Pbps</span>
            </span>
            <span className="text-white/10 hidden sm:inline">•</span>
            <span className="flex items-center gap-1.5">
              Latency: <span className="text-white font-mono font-medium">{metrics.latency}ms</span>
            </span>
            <span className="text-white/10 hidden sm:inline">•</span>
            <span className="flex items-center gap-1.5">
              Node Count: <span className="text-white font-mono font-medium">{metrics.nodeCount.toLocaleString()}</span>
            </span>
          </div>
        </div>

        <div className="text-[10px] text-white/30 shrink-0 uppercase tracking-wider text-center md:text-right">
          2026 © MSJ FUTURE TECH INC.
        </div>
      </footer>

      {/* Console Drawer Terminal */}
      <ConsoleTerminal
        isOpen={isConsoleOpen}
        onClose={() => setIsConsoleOpen(false)}
        logs={logs}
        onAddLog={addLog}
        onClearLogs={clearLogs}
        onRunSimulation={runSimulation}
      />

      {/* Code Viewer Modal Overlay */}
      <AnimatePresence>
        {showSourceCode && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSourceCode(null)}
              className="fixed inset-0 bg-black z-40 cursor-zoom-out"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-x-4 md:inset-x-0 md:w-[680px] top-[15%] md:mx-auto bg-[#0E0E0E] border border-white/20 p-6 rounded-sm z-50 font-mono shadow-2xl flex flex-col max-h-[70vh] overflow-hidden select-text"
            >
              <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-4">
                <div className="flex items-center gap-2">
                  <Code className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs uppercase tracking-widest font-bold text-white/80">
                    Source Compiler // {showSourceCode.id}
                  </span>
                </div>
                <button
                  onClick={() => setShowSourceCode(null)}
                  className="p-1 hover:bg-white/10 rounded text-white/40 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Code Panel */}
              <div className="flex-1 overflow-auto bg-black p-4 border border-white/5 rounded-xs">
                <pre className="text-xs text-emerald-400/90 leading-relaxed font-mono whitespace-pre select-text selection:bg-emerald-500/20">
                  {getProjectCode(showSourceCode)}
                </pre>
              </div>

              <div className="mt-4 pt-2 flex justify-between items-center text-[10px] text-white/40">
                <span>Language: TypeScript // ES Module Resolution</span>
                <button
                  onClick={() => setShowSourceCode(null)}
                  className="px-4 py-1.5 border border-white/10 hover:border-white/30 text-white hover:bg-white hover:text-black transition-all uppercase tracking-wider text-[9px]"
                >
                  Close Spec
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
