/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  Cpu, 
  Globe, 
  RefreshCw, 
  Activity, 
  TrendingDown, 
  TrendingUp, 
  Satellite, 
  Wifi, 
  Binary, 
  Layers 
} from 'lucide-react';
import { TabType, TelemetryMetrics } from '../types';

interface TabPanelsProps {
  activeTab: TabType;
  metrics: TelemetryMetrics;
  onPingComplete: (ping: number) => void;
  onUptimeRecalibrate: () => void;
  onAddLog: (log: { timestamp: string; sender: 'SYS' | 'USER' | 'WARN' | 'OK'; message: string }) => void;
}

export default function TabPanels({
  activeTab,
  metrics,
  onPingComplete,
  onUptimeRecalibrate,
  onAddLog,
}: TabPanelsProps) {
  // --- Quantum Lab State ---
  const [qubits, setQubits] = useState<'0' | '1' | 'H'[]>(() => Array(16).fill('H'));
  const [coherence, setCoherence] = useState(99.98);
  const [isMeasuring, setIsMeasuring] = useState(false);

  // --- Neural Net State ---
  const [epoch, setEpoch] = useState(3421);
  const [loss, setLoss] = useState<number[]>([0.89, 0.72, 0.61, 0.45, 0.38, 0.31, 0.28, 0.22, 0.19, 0.15]);
  const [isTraining, setIsTraining] = useState(false);
  const [selectedNode, setSelectedNode] = useState<number | null>(null);
  const [nodeWeights, setNodeWeights] = useState<number[]>(() => Array(8).fill(0).map(() => Math.random()));

  // --- Sub-Orbital State ---
  const [altitude, setAltitude] = useState(412.4); // km
  const [orbitalSpeed, setOrbitalSpeed] = useState(7.67); // km/s
  const [pings, setPings] = useState<number[]>([2, 4, 3, 2, 5, 2, 3]);
  const [isPingTesting, setIsPingTesting] = useState(false);

  // Simulate subtle environment shifts
  useEffect(() => {
    const timer = setInterval(() => {
      if (activeTab === 'quantum') {
        // Quantum coherence random fluctuations
        setCoherence((prev) => {
          const shift = (Math.random() - 0.5) * 0.04;
          return Math.max(95, Math.min(100, parseFloat((prev + shift).toFixed(4))));
        });
      } else if (activeTab === 'neural' && isTraining) {
        // Neural weight convergence
        setEpoch((prev) => prev + 1);
        setLoss((prev) => {
          const last = prev[prev.length - 1];
          const next = Math.max(0.01, parseFloat((last - Math.random() * 0.015).toFixed(4)));
          return [...prev.slice(1), next];
        });
      } else if (activeTab === 'sub-orbital') {
        // Altitude & speed orbital path adjustments
        setAltitude((prev) => parseFloat((prev + (Math.random() - 0.5) * 0.1).toFixed(2)));
        setOrbitalSpeed((prev) => parseFloat((prev + (Math.random() - 0.5) * 0.001).toFixed(4)));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [activeTab, isTraining]);

  // --- Quantum Actions ---
  const triggerQuantumMeasurement = () => {
    setIsMeasuring(true);
    onAddLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: 'BROADCASTING QUANTUM SUPERPOSITION MEASUREMENT FIELD...',
    });

    setTimeout(() => {
      setQubits((prev) => prev.map(() => (Math.random() > 0.5 ? '1' : '0')));
      const newCoherence = parseFloat((95 + Math.random() * 4.9).toFixed(4));
      setCoherence(newCoherence);
      setIsMeasuring(false);
      onAddLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: `MEASUREMENT COMPLETE. ENTIRE GRID RESOLVED. CORE COHERENCE: ${newCoherence}%`,
      });
    }, 1200);
  };

  const resetQuantumStates = () => {
    setQubits(Array(16).fill('H'));
    setCoherence(99.98);
    onAddLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: 'RE-ESTABLISHING COHERENT DECOUPLED QUBIT SUPERPOSITIONS.',
    });
  };

  const handleQubitClick = (idx: number) => {
    const nextQubits = [...qubits];
    if (nextQubits[idx] === 'H') {
      nextQubits[idx] = Math.random() > 0.5 ? '1' : '0';
      onAddLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'SYS',
        message: `Individually measured Qubit #${idx}: Collapsed to state |${nextQubits[idx]}⟩.`,
      });
    } else {
      nextQubits[idx] = 'H';
    }
    setQubits(nextQubits);
  };

  // --- Neural Actions ---
  const toggleTraining = () => {
    setIsTraining(!isTraining);
    onAddLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: isTraining ? 'Neural network training halted.' : 'Neural backpropagation sequence started.',
    });
  };

  const tuneWeight = (idx: number, delta: number) => {
    setNodeWeights((prev) => {
      const next = [...prev];
      next[idx] = Math.max(0, Math.min(1, parseFloat((next[idx] + delta).toFixed(3))));
      return next;
    });
    onAddLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: `Adjusted neural feedback weight Node #${idx} to: ${nodeWeights[idx].toFixed(3)}`,
    });
  };

  // --- Sub-Orbital Actions ---
  const triggerSatellitePing = () => {
    setIsPingTesting(true);
    onAddLog({
      timestamp: new Date().toLocaleTimeString(),
      sender: 'SYS',
      message: 'PING SIGNAL SENT TO CO-ORBITAL PLATFORM MSJ-SAT-4A...',
    });

    setTimeout(() => {
      const calculatedPing = parseFloat((1.2 + Math.random() * 4.1).toFixed(3));
      setPings((prev) => [...prev.slice(1), calculatedPing]);
      setIsPingTesting(false);
      onPingComplete(calculatedPing);
      onAddLog({
        timestamp: new Date().toLocaleTimeString(),
        sender: 'OK',
        message: `SAT-4A REACHABLE. RETURN TRIP: ${calculatedPing}ms (SATELLITE AZIMUTH 224.12°).`,
      });
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col justify-between">
      {/* 1. OVERVIEW SCREEN */}
      {activeTab === 'overview' && (
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.45em] mb-4 text-white/40 font-mono">
              EST. 2026 / CO-OPERATIONAL CONDUIT
            </p>
            <h1 className="text-[72px] sm:text-[100px] md:text-[125px] lg:text-[140px] leading-[0.8] font-black italic tracking-tighter uppercase mb-6 select-text select-none text-white font-serif">
              Future<br/>Gen.
            </h1>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-8 items-start sm:items-end mt-6">
            <div className="flex-1">
              <p className="text-base md:text-lg leading-relaxed text-white/75 max-w-sm font-sans">
                Architecting next-generation digital ecosystems through quantum-resistant security matrices and distributed neural nodes.
              </p>
            </div>
            <div className="flex gap-6 items-end">
              <button 
                onClick={onUptimeRecalibrate}
                className="text-right group cursor-pointer focus:outline-none focus:ring-1 focus:ring-white/20 p-2 border border-white/5 bg-white/[0.01] hover:bg-white/[0.04] transition-all"
              >
                <div className="text-[52px] md:text-[60px] font-light leading-none text-white tracking-tight font-sans flex items-baseline justify-end">
                  {metrics.uptime}%
                  <RefreshCw className="w-4 h-4 ml-2 text-white/30 group-hover:text-white/80 group-hover:rotate-180 transition-all duration-700 inline" />
                </div>
                <div className="text-[10px] uppercase tracking-widest text-white/40 mt-1">Uptime Calibration</div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. QUANTUM LAB SCREEN */}
      {activeTab === 'quantum' && (
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Binary className="w-5 h-5 text-sky-400" />
              <p className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-mono">
                QUANTUM LAB // PARTICLE SIMULATOR
              </p>
            </div>
            <h2 className="text-[44px] md:text-[56px] leading-[0.9] font-black uppercase tracking-tight text-white mb-6 font-serif italic">
              Superposition<br/>Field
            </h2>

            {/* Qubit grid */}
            <div className="grid grid-cols-4 gap-3 max-w-md my-6">
              {qubits.map((val, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQubitClick(idx)}
                  className={`h-12 border rounded-sm flex flex-col items-center justify-center transition-all ${
                    val === 'H' 
                      ? 'border-white/10 bg-white/[0.02] text-white/50 hover:bg-white/[0.08]' 
                      : val === '1'
                      ? 'border-sky-500/50 bg-sky-500/10 text-sky-300'
                      : 'border-white/30 bg-white/10 text-white font-bold'
                  }`}
                >
                  <span className="text-xs font-mono">q_{idx}</span>
                  <span className="text-sm font-semibold font-mono leading-none mt-0.5">
                    {val === 'H' ? '|ψ⟩' : `|${val}⟩`}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 mt-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] uppercase tracking-widest text-white/40 font-mono">Qubit Coherence</span>
                  <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-pulse"></span>
                </div>
                <div className="text-4xl font-light font-mono text-sky-300">{coherence}%</div>
                <p className="text-xs text-white/50 max-w-sm mt-2">
                  Measure the system to resolve the wave function superposition state into binary outputs.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={resetQuantumStates}
                  className="px-4 py-2 border border-white/20 hover:border-white/40 text-xs uppercase tracking-widest text-white/80 hover:text-white transition-all font-mono"
                >
                  Reset Field
                </button>
                <button
                  onClick={triggerQuantumMeasurement}
                  disabled={isMeasuring}
                  className={`px-5 py-2 text-xs uppercase tracking-widest font-mono font-bold border transition-all ${
                    isMeasuring 
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 cursor-wait'
                      : 'bg-white text-black hover:bg-transparent hover:text-white border-white'
                  }`}
                >
                  {isMeasuring ? 'Measuring...' : 'Measure Grid'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. NEURAL NET SCREEN */}
      {activeTab === 'neural' && (
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Layers className="w-5 h-5 text-emerald-400" />
              <p className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-mono">
                NEURAL CORE // FEEDBACK SYNAPSE
              </p>
            </div>
            <h2 className="text-[44px] md:text-[56px] leading-[0.9] font-black uppercase tracking-tight text-white mb-6 font-serif italic">
              Hyper-Edge<br/>Optimizer
            </h2>

            {/* Neural weights controller */}
            <div className="bg-white/[0.02] border border-white/10 p-5 rounded-sm max-w-lg my-4">
              <div className="flex justify-between items-center mb-4 border-b border-white/15 pb-2">
                <span className="text-xs uppercase tracking-wider text-white/60 font-mono">Node Weights</span>
                <span className="text-[10px] font-mono text-emerald-400 uppercase">
                  {isTraining ? '● Training Network' : '■ Standby'}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {nodeWeights.map((w, idx) => (
                  <div 
                    key={idx}
                    onClick={() => setSelectedNode(idx)}
                    className={`p-3 border rounded cursor-pointer transition-all ${
                      selectedNode === idx 
                        ? 'border-emerald-500 bg-emerald-500/10' 
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="text-[10px] font-mono text-white/40">Node #{idx}</div>
                    <div className="text-base font-mono font-bold text-white my-1">{w.toFixed(3)}</div>
                    <div className="flex gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); tuneWeight(idx, -0.05); }}
                        className="text-[10px] font-mono hover:text-white text-white/50 px-1 bg-white/5 hover:bg-white/15"
                      >
                        -
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); tuneWeight(idx, 0.05); }}
                        className="text-[10px] font-mono hover:text-white text-white/50 px-1 bg-white/5 hover:bg-white/15"
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 mt-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] uppercase tracking-widest text-white/40 font-mono">Training Status</span>
                  <span className="text-xs font-mono text-white/80">Epoch: {epoch}</span>
                </div>
                
                {/* Visual SVG Loss graph */}
                <div className="flex items-center gap-4 mt-2">
                  <div className="w-36 h-12 border border-white/5 bg-black/40 relative">
                    <svg className="w-full h-full" viewBox="0 0 100 30" preserveAspectRatio="none">
                      <path
                        d={`M ${loss.map((l, i) => `${(i / (loss.length - 1)) * 100} ${30 - l * 30}`).join(' L ')}`}
                        fill="none"
                        stroke="#34d399"
                        strokeWidth="1.5"
                      />
                    </svg>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-white/30 font-mono">Current Loss</div>
                    <div className="text-xl font-mono text-emerald-400 font-bold flex items-center gap-1">
                      {loss[loss.length - 1]}
                      <TrendingDown className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={toggleTraining}
                  className={`px-5 py-2 text-xs uppercase tracking-widest font-mono font-bold border transition-all ${
                    isTraining 
                      ? 'bg-emerald-500 text-black border-emerald-500 hover:bg-transparent hover:text-emerald-400'
                      : 'bg-white text-black hover:bg-transparent hover:text-white border-white'
                  }`}
                >
                  {isTraining ? 'Halt Training' : 'Start Backprop'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. SUB-ORBITAL SCREEN */}
      {activeTab === 'sub-orbital' && (
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Satellite className="w-5 h-5 text-amber-500" />
              <p className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-mono">
                TELEMETRY // GROUND STATION UPLINK
              </p>
            </div>
            <h2 className="text-[44px] md:text-[56px] leading-[0.9] font-black uppercase tracking-tight text-white mb-6 font-serif italic">
              Orbital Uplink
            </h2>

            {/* Orbit stats */}
            <div className="grid grid-cols-3 gap-4 my-6">
              <div className="p-4 border border-white/10 bg-white/[0.02] rounded-sm">
                <div className="text-[10px] uppercase tracking-wider text-white/40 font-mono">Orbital Alt.</div>
                <div className="text-xl md:text-2xl font-mono text-amber-500 font-semibold mt-1">{altitude} km</div>
                <div className="text-[9px] text-white/30 mt-1 uppercase font-mono">LOWER EARTH ORBIT</div>
              </div>
              <div className="p-4 border border-white/10 bg-white/[0.02] rounded-sm">
                <div className="text-[10px] uppercase tracking-wider text-white/40 font-mono">Uplink Speed</div>
                <div className="text-xl md:text-2xl font-mono text-amber-500 font-semibold mt-1">{orbitalSpeed} km/s</div>
                <div className="text-[9px] text-white/30 mt-1 uppercase font-mono">VELOCITY MAGNITUDE</div>
              </div>
              <div className="p-4 border border-white/10 bg-white/[0.02] rounded-sm">
                <div className="text-[10px] uppercase tracking-wider text-white/40 font-mono">Telemetry Sign.</div>
                <div className="text-xl md:text-2xl font-mono text-amber-500 font-semibold mt-1 flex items-center gap-1.5">
                  <Wifi className="w-5 h-5 text-amber-500 animate-pulse" />
                  98.2%
                </div>
                <div className="text-[9px] text-white/30 mt-1 uppercase font-mono">AZIMUTH OPTIMAL</div>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 mt-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6">
              <div className="flex-1">
                <div className="text-[10px] uppercase tracking-widest text-white/40 font-mono mb-1">Signal Round Trip</div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-mono text-amber-400">{pings[pings.length - 1].toFixed(3)} ms</span>
                  <div className="flex items-end h-6 gap-1 border-l border-white/10 pl-3">
                    {pings.map((p, i) => (
                      <span 
                        key={i} 
                        className="w-1.5 bg-amber-500/30 hover:bg-amber-500 transition-colors" 
                        style={{ height: `${Math.min(100, (p / 6) * 100)}%` }} 
                        title={`${p}ms`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <button
                  onClick={triggerSatellitePing}
                  disabled={isPingTesting}
                  className={`px-5 py-2 text-xs uppercase tracking-widest font-mono font-bold border transition-all ${
                    isPingTesting 
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 cursor-wait'
                      : 'bg-white text-black hover:bg-transparent hover:text-white border-white'
                  }`}
                >
                  {isPingTesting ? 'Pinging SAT...' : 'Ping Satellite'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
