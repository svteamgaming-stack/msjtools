/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal as TerminalIcon, X, Send, Play, CornerDownLeft } from 'lucide-react';
import { TerminalLog } from '../types';

interface ConsoleTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: TerminalLog[];
  onAddLog: (log: TerminalLog) => void;
  onClearLogs: () => void;
  onRunSimulation: (type: 'quantum' | 'neural' | 'sub-orbital') => void;
}

const COMMANDS = [
  { cmd: 'help', desc: 'Display all available system protocols.' },
  { cmd: 'status', desc: 'Print active core telemetry reports.' },
  { cmd: 'quantum-spin', desc: 'Trigger a local quantum qubit state collapse.' },
  { cmd: 'neural-sync', desc: 'Synchronize high-dimensional neural node weights.' },
  { cmd: 'orbital-ping', desc: 'Verify connection to sub-orbital nodes.' },
  { cmd: 'clear', desc: 'Purge console display buffer.' },
  { cmd: 'reboot', desc: 'Perform a soft system mainframe cycle.' },
];

export default function ConsoleTerminal({
  isOpen,
  onClose,
  logs,
  onAddLog,
  onClearLogs,
  onRunSimulation,
}: ConsoleTerminalProps) {
  const [inputVal, setInputVal] = useState('');
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isOpen]);

  const handleCommand = (cmdStr: string) => {
    const trimmed = cmdStr.trim().toLowerCase();
    if (!trimmed) return;

    const timestamp = new Date().toLocaleTimeString();
    
    // User log
    onAddLog({
      timestamp,
      sender: 'USER',
      message: `> ${cmdStr}`,
    });

    setTimeout(() => {
      const responseTime = new Date().toLocaleTimeString();
      switch (trimmed) {
        case 'help':
          onAddLog({
            timestamp: responseTime,
            sender: 'SYS',
            message: '--- AVAILABLE MAINBOARD COMMANDS ---',
          });
          COMMANDS.forEach((c) => {
            onAddLog({
              timestamp: responseTime,
              sender: 'SYS',
              message: `  ${c.cmd.padEnd(15)} - ${c.desc}`,
            });
          });
          break;
        case 'status':
          onAddLog({
            timestamp: responseTime,
            sender: 'SYS',
            message: 'RETRIEVING INTEGRATED NETWORK STATISTICS...',
          });
          setTimeout(() => {
            onAddLog({
              timestamp: new Date().toLocaleTimeString(),
              sender: 'OK',
              message: `[SYS_OK] CORE LOAD: 34.2% | QUANTUM COHERENCE: 99.98% | LATENCY: 0.002ms`,
            });
            onAddLog({
              timestamp: new Date().toLocaleTimeString(),
              sender: 'OK',
              message: `[SYS_OK] ACTIVE NODES: 14,291 | NETWORK TRAFFIC: OPTIMAL`,
            });
          }, 300);
          break;
        case 'quantum-spin':
          onAddLog({
            timestamp: responseTime,
            sender: 'SYS',
            message: 'INITIALIZING SPIN RESONANCE FIELD MEASUREMENT...',
          });
          onRunSimulation('quantum');
          break;
        case 'neural-sync':
          onAddLog({
            timestamp: responseTime,
            sender: 'SYS',
            message: 'COMMENCING GRADIENT SYNC ACROSS MULTI-EDGE CORRIDORS...',
          });
          onRunSimulation('neural');
          break;
        case 'orbital-ping':
          onAddLog({
            timestamp: responseTime,
            sender: 'SYS',
            message: 'BROADCASTING SUB-ORBITAL ULTRABAND BEACON...',
          });
          onRunSimulation('sub-orbital');
          break;
        case 'clear':
          onClearLogs();
          break;
        case 'reboot':
          onClearLogs();
          onAddLog({
            timestamp: responseTime,
            sender: 'WARN',
            message: 'WARM MAINBOARD REBOOT INITIATED...',
          });
          setTimeout(() => {
            onAddLog({
              timestamp: new Date().toLocaleTimeString(),
              sender: 'OK',
              message: 'SYSTEM BOOT SUCCESSFUL. V4.0.21 INSTANTIATED.',
            });
          }, 600);
          break;
        default:
          onAddLog({
            timestamp: responseTime,
            sender: 'WARN',
            message: `Command not recognized: '${trimmed}'. Type 'help' for protocols.`,
          });
      }
    }, 150);

    setInputVal('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleCommand(inputVal);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-40"
          />

          {/* Drawer Console */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="fixed bottom-0 left-0 right-0 h-[480px] bg-[#060606] border-t border-white/20 z-50 flex flex-col font-mono text-sm text-[#E5E5E5] select-text shadow-2xl"
          >
            {/* Console Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-white/10 bg-black">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-xs uppercase tracking-[0.25em] font-bold text-white/70 flex items-center gap-2">
                  <TerminalIcon className="w-4 h-4 text-white/50" />
                  Core Console Command Interface
                </span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-[10px] text-white/40 uppercase hidden sm:inline">Press ESC or click close</span>
                <button
                  onClick={onClose}
                  className="p-1 hover:bg-white/10 rounded text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Split layout: left logs, right quick actions */}
            <div className="flex-1 flex overflow-hidden">
              {/* Output screen */}
              <div className="flex-1 p-6 overflow-y-auto flex flex-col gap-2 bg-gradient-to-b from-[#060606] to-[#0A0A0A]">
                {logs.length === 0 ? (
                  <div className="text-white/30 italic text-xs py-10 text-center">
                    Console ready. Select a protocol or enter commands below. Type 'help' to see options.
                  </div>
                ) : (
                  logs.map((log, idx) => (
                    <div key={idx} className="flex gap-4 items-start text-xs leading-relaxed">
                      <span className="text-white/30 select-none shrink-0">{log.timestamp}</span>
                      <span
                        className={`font-semibold shrink-0 select-none ${
                          log.sender === 'USER'
                            ? 'text-white'
                            : log.sender === 'WARN'
                            ? 'text-amber-500'
                            : log.sender === 'OK'
                            ? 'text-emerald-500'
                            : 'text-sky-400'
                        }`}
                      >
                        [{log.sender}]
                      </span>
                      <span className="whitespace-pre-wrap flex-1 text-white/90">{log.message}</span>
                    </div>
                  ))
                )}
                <div ref={logEndRef} />
              </div>

              {/* Quick Actions (Sidebar inside terminal) */}
              <div className="w-72 border-l border-white/10 bg-[#080808] p-6 flex flex-col gap-4 hidden md:flex">
                <div className="text-[10px] font-bold tracking-widest text-white/40 uppercase border-b border-white/10 pb-2">
                  Preset Directives
                </div>
                <div className="flex flex-col gap-2.5 flex-1 overflow-y-auto">
                  {COMMANDS.map((c) => (
                    <button
                      key={c.cmd}
                      onClick={() => handleCommand(c.cmd)}
                      className="text-left py-1.5 px-3 border border-white/5 bg-white/[0.02] hover:bg-white/[0.08] hover:border-white/25 text-xs text-white/80 rounded transition-all group flex items-center justify-between"
                    >
                      <span className="font-mono text-emerald-400 font-medium group-hover:text-emerald-300">
                        {c.cmd}
                      </span>
                      <Play className="w-3 h-3 opacity-0 group-hover:opacity-100 text-white/60 transition-opacity" />
                    </button>
                  ))}
                </div>
                <div className="text-[10px] text-white/30 text-center mt-auto font-sans leading-relaxed">
                  Interactive Terminal V4.0 // Fully responsive virtualized network simulation.
                </div>
              </div>
            </div>

            {/* Input form */}
            <form
              onSubmit={handleSubmit}
              className="border-t border-white/10 p-4 bg-black flex gap-3 items-center"
            >
              <span className="text-emerald-400 font-bold font-mono pl-2 select-none">&gt;</span>
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="Initialize protocol (e.g. status, quantum-spin, help)..."
                className="flex-1 bg-transparent border-none outline-none focus:ring-0 text-white font-mono text-sm placeholder-white/20 py-2"
                autoFocus
              />
              <button
                type="submit"
                className="px-4 py-2 border border-white/20 bg-white/5 hover:bg-white text-white hover:text-black transition-all rounded flex items-center gap-2 text-xs uppercase tracking-widest"
              >
                <span>Execute</span>
                <CornerDownLeft className="w-3.5 h-3.5" />
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
